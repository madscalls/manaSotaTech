WHELK WORKS — SOCIAL ADS (FREE SITE CHECK CAMPAIGN)
9 square ads, 1080 x 1080 (Instagram / Facebook feed)

=====================================================
HOW TO EDIT IN CANVA
=====================================================
1. In Canva, click Upload > Upload files and choose "Whelk Works ads - all 9.pdf"
   (or one of the single-ad PDFs in the "PDF - one per ad" folder).
2. Click the uploaded file to open it as a design. Each page is one ad.
3. Headlines, body text and buttons come in as editable text boxes; shapes come
   in as separate elements you can move or recolor.
4. If a font looks off, re-select it in Canva. All three are free in Canva:
     Outfit (headlines, buttons)
     Manrope (body text)
     Caveat (handwritten note in the bottle ad)
5. Some layered effects (waves, stripes, radar sweep, lighthouse beam) may
   import as images or need a small nudge. The PNG files show exactly how each
   ad should look.

PNG files = finished, ready-to-post versions (not editable).

=====================================================
COLORS
=====================================================
Ads 1-3 and 7-9 ("free site check" palette)
  Turquoise Surf  #06AED5
  Cerulean        #086788
  Deep ink        #053F52
  Bright Amber    #F0C808
  Lobster Pink    #DB5461
  Bright Snow     #FAFAFA

Ads 4-6 (red + blue palette)
  Navy            #13315C
  Deep navy       #0B2545
  Bright blue     #3E7BFA
  Sky blue        #8EC5FF
  Deep red        #C1121F
  Coral red       #FF5A5F
  White           #FAFAFA

=====================================================
CAPTIONS
=====================================================
Contact: whelkworks.com · (941) 529-1285 · hello@whelkworks.com

01 — Is your business on AI's radar?
When locals ask AI where to go, it recommends the businesses it can find. If you're only on Instagram, you're not on the screen.
We put your business where AI and Google can see it, so more customers walk through your door. It's FREE to check where you stand.
whelkworks.com · (941) 529-1285

02 — Page two is the bottom of the ocean.
People pick from the top few results, and AI only names a handful. Everyone else might as well be underwater.
We bring your business to the surface so more customers find you. FREE 20-minute check, no pitch.
whelkworks.com

03 — Give AI a map to your door.
AI can only recommend what it can find. We put your hours, menu and address where it can see them, so more customers show up.
Want to know if AI can find you? It's FREE to check.
whelkworks.com

04 — Be the place AI points customers to.
Ask AI where to go and it points to just a few places. We help make sure one of them is yours, so more customers find their way to you.
It's FREE to check where you stand: whelkworks.com · (941) 529-1285

05 — Customers shouldn't need a message in a bottle to find you.
If your hours, menu and phone number are buried in old posts, people give up and go somewhere else. We make them easy to find on Google and AI, so more customers reach you.
FREE 20-minute check, no pitch: whelkworks.com

06 — Reel in more customers.
Locals, tourists, regulars: they're all looking. We'll show you, for FREE, how people find businesses like yours on Google and AI, and what's keeping them from finding you.
whelkworks.com

07 — Don't let customers sail right past you.
People are looking for places like yours right now, on Google and AI. If they can't find you, they keep going. We help them drop anchor at your door.
It's FREE to check: whelkworks.com · (941) 529-1285

08 — Hidden gems are great. Hidden businesses aren't.
Locals love a hidden gem, but they still have to find it. We get you showing up on Google and AI, so more customers discover you.
FREE 20-minute site check, no pitch: whelkworks.com

09 — Lost online? We'll throw you a line.
Not sure how customers are finding you, or if they are? In 20 FREE minutes, we'll look at how people find you on Google and AI and show you what to fix to bring more of them in.
Grab the FREE check: whelkworks.com

Suggested hashtags (mix and match):
#SarasotaSmallBusiness #ShopLocalSRQ #SRQ #BradentonBusiness #VeniceFL #SiestaKey #AnnaMariaIsland #SarasotaEats #ShopSmallSRQ
